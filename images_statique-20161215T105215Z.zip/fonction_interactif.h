#ifndef fonction_interactif
#define fonction_interactif

int getch(void);

#endif